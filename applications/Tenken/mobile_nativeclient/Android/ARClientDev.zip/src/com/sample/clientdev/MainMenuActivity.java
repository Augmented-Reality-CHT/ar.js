/*----------------------------------------------------------------------------
 * COPYRIGHT 2013-2014 FUJITSU LIMITED
 *----------------------------------------------------------------------------*/
package com.sample.clientdev;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.fujitsu.interstage.ar.mobileclient.android.base.BaseDefine;
import com.fujitsu.interstage.ar.mobileclient.android.util.DeviceUtil;

/**
 * サンプルメニューActivityです。
 */
public class MainMenuActivity extends Activity {

	private MenuItem mMenuItemSetting = null;
	private static String PREF_KEY = "pref_key_inputurl";  
	/**
     * 設備タイプを示すフィールド変数です。
     */
    private boolean isPad = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		 isPad = DeviceUtil.isTabletDevice(this);
		if(isPad)
		{
			setContentView(R.layout.mainmenu);
		}
		else
		{
			setContentView(R.layout.mainmenuforphone);
		}
		GridView gridview = (GridView) findViewById(R.id.ar_gridview);
		gridview.setAdapter(new ImageAdapter(this));
		gridview.setOnItemClickListener(new OnItemClickListener(){
			public void onItemClick(AdapterView<?> parent, View v, int _position, long id)
			{
				switch (_position) {
				case 0:
					SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(MainMenuActivity.this);
					String inputText = pref.getString(PREF_KEY, "null");
					final EditText mEditText = new EditText(MainMenuActivity.this);
					mEditText.setSingleLine();
					if(!inputText.equals("null")){
						mEditText.setText(inputText);
					}
					new AlertDialog.Builder(MainMenuActivity.this).setTitle("Server URL").setView(mEditText)
							.setNegativeButton("Start AR", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog, int which) {
									//入力値を保存します。
					                SharedPreferences inputpref =
					                        PreferenceManager.getDefaultSharedPreferences(MainMenuActivity.this);
					                SharedPreferences.Editor editor = inputpref.edit();
					                String text = mEditText.getText().toString();
					                editor.putString(PREF_KEY, text);
					                editor.commit();

					                //起動URLを取得します。
									String url = mEditText.getText().toString();

									// AR重畳表示アプリケーションAcitivityをintentに設定します。
									String _activity = "com.fujitsu.interstage.ar.mobileclient.android.base.web.ArWebMainActivity";
							        Intent intent = new Intent();
							        intent.setClassName(MainMenuActivity.this, _activity);
									// 起動するURLをintentに設定します。
									// key: extraskey_widget_url
									// value: URL
									intent.putExtra("extraskey_widget_url", url);
									// Activityを起動します。
									startActivity(intent);
								}

							}).setPositiveButton("Cancel", new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog, int which) {
								}
							}).show();
					break;
				case 1:
					startAuthoringActivity();
					break;
			}
			}
		});
	}
    
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		mMenuItemSetting = menu.add(R.string.menu_setting);
		mMenuItemSetting.setIcon(android.R.drawable.ic_menu_preferences);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item == mMenuItemSetting) {
			startPreferenceActivity();
		}
		return true;
	}

	private void startAuthoringActivity() {
		// クライアントオーサリングAcitivityをintentに設定します。
		String _activity = "com.fujitsu.interstage.ar.mobileclient.android.authoring.ui.LiveAuthoringActivity";
		Intent intent = new Intent();
		intent.setClassName(this, _activity);
		// Activityを起動します。
		startActivity(intent);
	}

	private void startPreferenceActivity() {
		// 設定画面Acitivityをintentに設定します。
		String _activity = "com.fujitsu.interstage.ar.mobileclient.android.base.pref.ArPreferenceActivity";
		Intent intent = new Intent();
		intent.setClassName(this, _activity);
		// Activityを起動します。
		startActivity(intent);
	}
	
	public class ImageAdapter extends BaseAdapter
	{
		private LayoutInflater mInflater;
		private Integer[]  mImageIds ={R.drawable.ar_application,R.drawable.ar_authoring};
		private String[] mColors={BaseDefine.ARAPPLICATION_COLOR,BaseDefine.ARAUTHORING_COLOR};
		private String[] mNames={getResources().getString(R.string.menu_arwebapp),getResources().getString(R.string.menu_arauthoring)};
		
		private final class ViewHolder {
			public ImageView imageView;
			public TextView textView;
		}
		
		public ImageAdapter(Context c)
		{
			mInflater = LayoutInflater.from(c);
		}
		
		public View getView(int position, View convertView, ViewGroup parent)
		{
			ViewHolder viewHolder = new ViewHolder();
			if (convertView == null)
			{
				if(isPad)
				{
					convertView = mInflater.inflate(R.layout.ar_imageview_text, null);
				}
				else
				{
					convertView = mInflater.inflate(R.layout.ar_imageview_textforphone, null);
				}
				viewHolder.imageView = (ImageView)convertView.findViewById(R.id.ar_imageview);
				viewHolder.textView = (TextView)convertView.findViewById(R.id.ar_textview);
				convertView.setTag(viewHolder);
			}
			else
			{
				viewHolder = (ViewHolder)convertView.getTag();
			}
			viewHolder.imageView.setImageResource(mImageIds[position]);
			viewHolder.imageView.setBackgroundColor(Color.parseColor(mColors[position]));
			viewHolder.textView.setText(mNames[position]);
			
			return convertView;
		}
		
		@Override
		public int getCount() {
			return mImageIds.length;
		}
		@Override
		public Object getItem(int arg0) {
			return arg0;
		}
		@Override
		public long getItemId(int arg0) {
			return arg0;
		}
	}
}
